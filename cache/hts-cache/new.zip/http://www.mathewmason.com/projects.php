<?xml version='1.0' encoding='UTF-8'?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>Mathew Mason DOT com</title>
		
		<link rel="stylesheet" href="styles/general.css" type="text/css" />
		
		<script src="scripts/ufo.js" type="text/javascript"></script>
	</head>
	 	<body id="blog">
		<div id="page">
			<div id="header">
				<a href="index.php" title="Main Page"><img src="images/banner.jpg" alt="MathewMasonDOTcom" /></a>			</div>
			<div id="body">
				<div class="article">
<h1><a href="/projects.php?id=19" title="View and post comments for Sphere">Sphere</a></h1>
<h4>Posted by <a href="mailto:masonm12@gmail.com" title="E-Mail Mathew at masonm12@gmail.com">Mathew</a> on December 16th, 2008</h4>
<br />
<p style="text-align: center;"><img src="images/sphere.jpg" alt="Sphere" /></p><h4 style="text-align: center;">3D Puzzle Shooter</h4><h2>Downloads:</h2><p><a href="programs/Sphere.exe" title="Download | Sphere">Sphere (Windows)</a> - <a href="programs/SphereOSX.zip" title="Download | Sphere">Sphere (OSX)</a></p><h2>Links:</h2><p><a href="programs/SpherePlayer.html" title="Hyperlink | Sphere">Sphere (Web Player)</a></p>
<h2>Team Sphere:</h2><ul><li><strong>Programming</strong><ul><li><a href="mailto:masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">Mathew Mason (Me)</a></li><li><a href="mailto:sommerbr@msu.edu" title="Email Bruno Sommer at sommerbr@msu.edu">Bruno Sommer</a></li></ul></li><li><strong>3D Art</strong><ul><li><a href="mailto:shillai6@msu.edu" title="Email Daniel Shillair at shillai6@msu.edu">Daniel Shillair</a></li><li><a href="mailto:cooleyn2@msu.edu" title="Email Nathan Cooley at cooleyn2@msu.edu">Nathan Cooley</a></li></ul></li><li><strong>Design</strong><ul><li><a href="mailto:pollitta@msu.edu" title="Email Andrea Pollitt at pollitta@msu.edu">Andrea Pollitt</a></li></ul></li><li><strong>Audio</strong><ul><li><a href="mailto:brown142@msu.edu" title="Email Jason Brown at brown142@msu.edu">Jason Brown</a></li></ul></li></ul><h2>Platform:</h2><p>Made using the Unity 3D game engine</p><h2>Notes:</h2><p>Made as a final project in TC 455, 3D Game Design, Sphere was the first project where the Unity 3D game engine really clicked for me. Trying to learn from other projects in the class we scoped our project much lower, going for a 3D version of the classic match 3 game play, and adding high score, powerup, and achievement functionality to spice it up. More information can be found in the game's menus.</p><br /><h4 style="text-align: center;">Posted in <a href="/projects.php?category=Academic" title="All Academic posts">Academic</a>, <a href="/projects.php?type=Game" title="All Game posts">Game</a></h4>

</div>

<div class="article">
<h1><a href="/projects.php?id=18" title="View and post comments for Save Your Brains!">Save Your Brains!</a></h1>
<h4>Posted by <a href="mailto:masonm12@gmail.com" title="E-Mail Mathew at masonm12@gmail.com">Mathew</a> on December 16th, 2008</h4>
<br />
<p style="text-align: center;"><img src="images/saveyourbrains.jpg" alt="Save Your Brains!" /></p><h4 style="text-align: center;">Zombie Horde Action</h4><h2>Downloads:</h2><p><a href="programs/SaveYourBrains.exe" title="Download | Save Your Brains!">Save Your Brains!</a></p>
<h2>Team Reanimated:</h2><ul><li><strong>Programming</strong><ul><li><a href="mailto:masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">Mathew Mason (Me)</a></li><li><a href="mailto:monosmit@msu.edu" title="Email Chris Monosmith at monosmit@msu.edu">Chris Monosmith</a></li><li><a href="mailto:starksad@msu.edu" title="Email Adam Starks at starksad@msu.edu">Adam Starks</a></li><li><a href="mailto:sommerbr@msu.edu" title="Email Bruno Sommer at sommerbr@msu.edu">Bruno Sommer</a></li></ul></li><li><strong>3D Art</strong><ul><li><a href="mailto:lazarmar@msu.edu" title="Email Marie Lazar at lazarmar@msu.edu">Marie Lazar</a></li></ul></li><li><strong>Design</strong><ul><li><a href="mailto:ajlounij@msu.edu" title="Email Jordan Ajlouni at ajlounij@msu.edu">Jordan Ajlouni</a></li></ul></li><li><strong>Audio</strong><ul><li><a href="mailto:prainit3@msu.edu" title="Email Michael Prainito at prainit3@msu.edu">Michael Prainito</a></li></ul></li></ul><h2>Platform:</h2><p>Made using Microsoft's XNA 2.0 Framework</p><h2>Notes:</h2><p>Made first as an entry for the second GameJam of our 2008 Fall semester here at MSU, and then later modified for a class project, this is the first effort of my new core team in several areas, including group AI, simple physics, and networking. While we haven't optimized much of the net code, it works fairly well for the 2 player limit we've imposed, especially via LAN connections.

Of particular note is the art in the game. Originally our 3D artist, Marie, had worked up some impressive, skinned, animated models for use, but some unforseen problems involving Blender and XNA forced us to use our backup programming art, which is seen in the player, zombie, gas cans, and flames, as well as 3D particles used for zombie brains. Our programmer artist was Adam Starks (mentioned above).</p><br /><h4 style="text-align: center;">Posted in <a href="/projects.php?category=Personal" title="All Personal posts">Personal</a>, <a href="/projects.php?type=Game" title="All Game posts">Game</a></h4>

</div>

<div class="article">
<h1><a href="/projects.php?id=17" title="View and post comments for XNA 2.0 Installer">XNA 2.0 Installer</a></h1>
<h4>Posted by <a href="mailto:masonm12@gmail.com" title="E-Mail Mathew at masonm12@gmail.com">Mathew</a> on December 16th, 2008</h4>
<br />
<p style="text-align: center;"><img src="images/xna2_0installer.jpg" alt="XNA 2.0 Installer" /></p><h4 style="text-align: center;">XNA Installer Script</h4><h2>Downloads:</h2><p><a href="programs/xna2_0installer.zip" title="Download | XNA 2.0 Installer">XNA 2.0 Installer</a></p>
<p>This is a script I worked up using some community resources to build installers for games based on Microsoft's XNA 2.0 framework. Inside the archive linked above you'll find a PDF readme that should explain more, along with links to resources I used and some suggested improvements for the future.</p><br /><h4 style="text-align: center;">Posted in <a href="/projects.php?category=Personal" title="All Personal posts">Personal</a>, <a href="/projects.php?type=Game" title="All Game posts">Game</a></h4>

</div>

<div class="article">
<h1><a href="/projects.php?id=16" title="View and post comments for Space Chase Race!">Space Chase Race!</a></h1>
<h4>Posted by <a href="mailto:masonm12@gmail.com" title="E-Mail Mathew at masonm12@gmail.com">Mathew</a> on October 9th, 2008</h4>
<br />
<p style="text-align: center;"><img src="images/spacechaserace.jpg" alt="Space Chase Race!" /></p><h4 style="text-align: center;">Racing, Chasing, Space Game</h4><h2>Downloads:</h2><p><a href="programs/SpaceChaseRace.exe" title="Download | Space Chase Race!">Space Chase Race!</a></p>
<h2>Team Hiro:</h2><ul><li><strong>Programming</strong><ul><li><a href="mailto:masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">Mathew Mason (Me)</a></li><li><a href="mailto:monosmit@msu.edu" title="Email Chris Monosmith at monosmit@msu.edu">Chris Monosmith</a></li><li><a href="mailto:dziadzi2@msu.edu" title="Email Paul Dziadzio at dziadzi2@msu.edu">Paul Dziadzio</a></li><li><a href="mailto:roger109@msu.edu.edu" title="Email Mark Rogers at roger109@msu.edu.edu">Mark Rogers</a></li><li><a href="mailto:fetscoma@msu.edu" title="Email Mary Fetsco at fetscoma@msu.edu">Mary Fetsco</a></li></ul></li></ul><h2>Platform:</h2><p>Made using the XNA framework and C#.</p><h2>Notes:</h2><p>Completed as a first project in CSE 491, Fundamentals of Game Programming, this project turned out a bit messy to be honest. It was the first game where we really wanted the XBox controller to be the main form of input, and even allows two players to play simultaneously in a split screen mode should the player have two controllers available. Overall I think we did some interesting things in this project, but we simply did not have the time to make it into a polished product.</p><br /><h4 style="text-align: center;">Posted in <a href="/projects.php?category=Academic" title="All Academic posts">Academic</a>, <a href="/projects.php?type=Game" title="All Game posts">Game</a></h4>

</div>

<div class="article">
<h1><a href="/projects.php?id=15" title="View and post comments for Blobbo!">Blobbo!</a></h1>
<h4>Posted by <a href="mailto:masonm12@gmail.com" title="E-Mail Mathew at masonm12@gmail.com">Mathew</a> on September 28th, 2008</h4>
<br />
<p style="text-align: center;"><img src="images/blobbo.jpg" alt="Blobbo!" /></p><h4 style="text-align: center;">Virtual Pet Blob Simulation</h4><h2>Downloads:</h2><p><a href="programs/Blobbo!.exe" title="Download | Blobbo!">Blobbo!</a></p>
<h2>Team Border Patrol:</h2><ul><li><strong>Programming</strong><ul><li><a href="mailto:masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">Mathew Mason (Me)</a></li><li><a href="mailto:monosmit@msu.edu" title="Email Chris Monosmith at monosmit@msu.edu">Chris Monosmith</a></li></ul></li><li><strong>3D Art</strong><ul><li><a href="mailto:prinkemi@msu.edu" title="Email Mike Prinke at prinkemi@msu.edu">Mike Prinke</a></li></ul></li><li><strong>2D Art</strong><ul><li><a href="mailto:impishkitten904@yahoo.com" title="Email Shannon Lemons at impishkitten904@yahoo.com">Shannon Lemons</a></li><li><a href="mailto:magic_shield2001@yahoo.com" title="Email Ashleigh Dringenberg at magic_shield2001@yahoo.com">Ashleigh Dringenberg</a></li></ul></li><li><strong>Design</strong><ul><li><a href="mailto:ajlounij@msu.edu" title="Email Jordan Ajlouni at ajlounij@msu.edu">Jordan Ajlouni</a></li><li><a href="mailto:aaronpreston1@sbcglobal.net" title="Email Aaron Preston @ aaronpreston@sbcglobal.net">Aaron Preston</a></li><li><a href="mailto:cornish6@msu.edu" title="Email Chris Cornish at cornish6@msu.edu">Chris Cornish</a></li></ul></li></ul><h2>Platform:</h2><p>Made as my first real 3D game using XNA.</p><h2>Notes:</h2><p>Made for the first 48 Hour Game Jam of the 2008-2009 school year at Michigan State Univeristy, where we tied for third out of 6 possible entries. Our group consisted of 8 people ranging from Freshmen to Seniors, and we wanted to all learn something. That being said we went with a virtual pet game design. Not my most complete project, but I think it turned out pretty neat. Something I may visit in the future. Even if not my greatest result I think it's the tightest feeling game I've made yet, and if nothing else I feel as though I learned quite a bit.</p><br /><h4 style="text-align: center;">Posted in <a href="/projects.php?category=Personal" title="All Personal posts">Personal</a>, <a href="/projects.php?type=Game" title="All Game posts">Game</a></h4>

</div>

<div class="entries"><div class="nextentry"><a href="/projects.php?offset=5" title="Older Posts">Older Posts (6-10) &gt;&gt;</a></div></div>			</div>
			<div id="sidebar">
				<div class="sidebox">
	<h2>Links: </h2>
	<p>
		<a href="index.php" title="Blog">Blog</a><br />
		<a href="projects.php" title="Projects">Projects</a><br />
		<a href="about.php" title="About">About</a><br />
		<a href="texts/resume.pdf" title="PDF | Resume">Resume</a><br />
		<a href="mailto: masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">Email</a>
	</p>
</div>				<div class="sidebox">
					<h2>Archive:</h2><p>
<a href="/projects.php?month=12&amp;year=2008" title="Posts for December, 2008">December, 2008 (3)</a><br /><a href="/projects.php?month=10&amp;year=2008" title="Posts for October, 2008">October, 2008 (1)</a><br /><a href="/projects.php?month=9&amp;year=2008" title="Posts for September, 2008">September, 2008 (1)</a><br /><a href="/projects.php?month=7&amp;year=2008" title="Posts for July, 2008">July, 2008 (1)</a><br /><a href="/projects.php?month=5&amp;year=2008" title="Posts for May, 2008">May, 2008 (1)</a><br /><a href="/projects.php?month=4&amp;year=2008" title="Posts for April, 2008">April, 2008 (1)</a><br /><a href="/projects.php?month=2&amp;year=2008" title="Posts for February, 2008">February, 2008 (2)</a><br /><a href="/projects.php?month=1&amp;year=2008" title="Posts for January, 2008">January, 2008 (2)</a><br /><a href="/projects.php?month=11&amp;year=2007" title="Posts for November, 2007">November, 2007 (3)</a><br /><a href="/projects.php?month=9&amp;year=2007" title="Posts for September, 2007">September, 2007 (1)</a><br /><a href="/projects.php?month=8&amp;year=2007" title="Posts for August, 2007">August, 2007 (1)</a><br /><a href="/projects.php?month=6&amp;year=2007" title="Posts for June, 2007">June, 2007 (2)</a><br />
</p>
				</div>
				<div class="sidebox">
					<h2>Category:</h2><p>
<a href="/projects.php?category=Academic" title="All Academic posts">Academic (11)</a><br /><a href="/projects.php?category=Personal" title="All Personal posts">Personal (8)</a><br />
</p>
				</div>
				<div class="sidebox">
					<h2>Type:</h2><p>
<a href="/projects.php?type=Audio" title="All Audio posts">Audio (1)</a><br /><a href="/projects.php?type=Game" title="All Game posts">Game (14)</a><br /><a href="/projects.php?type=Graphics" title="All Graphics posts">Graphics (1)</a><br /><a href="/projects.php?type=Video" title="All Video posts">Video (1)</a><br /><a href="/projects.php?type=Web" title="All Web posts">Web (2)</a><br />
</p>
				</div>
				<div class="sidebox">
	<div class="buttons">
		<a href="http://profile.mygamercard.net/masonofsparta" title="Mathew's GamerTag | MasonOfSparta">
			<img src="http://card.mygamercard.net/masonofsparta.png" alt="Mathew's GamerTag | MasonOfSparta" />
		</a>
		<a href="http://www.spreadfirefox.com/node&amp;id=0&amp;t=321"><img alt="Foxkeh" title="Foxkeh" src="http://images.spreadfirefox.com/affiliates/Buttons/firefox3/foxkeh-fx3-180x60.png"/></a>
		<br />
		<a href="http://validator.w3.org/check?uri=referer"><img
			src="http://www.w3.org/Icons/valid-xhtml10"
			alt="Valid XHTML 1.0 Strict" /></a>
		<a href="http://jigsaw.w3.org/css-validator/">
			<img style="border:0;"
				src="http://jigsaw.w3.org/css-validator/images/vcss"
				alt="Valid CSS!" /></a>
	</div>
</div>			</div>
			<div id="footer">
				<h4>Design, development, and most everything else by <a href="mail:masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">Mathew Mason</a>, &copy; 2008.</h4>			</div>
		</div>
	</body>
</html>