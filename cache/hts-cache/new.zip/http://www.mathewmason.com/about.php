<?xml version='1.0' encoding='UTF-8'?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>Mathew Mason DOT com</title>
		
		<link rel="stylesheet" href="styles/general.css" type="text/css" />
		
		<script src="scripts/ufo.js" type="text/javascript"></script>
	</head>
	 	<body id="error">
		<div id="page">
			<div id="header">
				<a href="index.php" title="Main Page"><img src="images/banner.jpg" alt="MathewMasonDOTcom" /></a>			</div>
			<div id="body">
								<div class="article">
					<h1>About this site, and me!</h1>
					<br />
					<p>
						I created this site to host my thoughts, projects, and other personal information that may or may not be wise to put on the internet. It's my hope to use this site to encourage myself to get my thoughts and work hosted for the world to see (should they stumble upon it) and to learn a little bit about server side web programming in the process.
						<br /><br />
						I am a double degree student at <a class="msu" href="http://www.msu.edu" title="www.MSU.edu | Michigan State University">Michigan State University</a>, seeking a <strong>BS in Computer Science and Engineering</strong>, and a <strong>BA in Telecommunication, Information Studies and Media</strong>. I am also interested in attaining an <em>emphasis on Digital Media Art and Technology</em>, with a <em>specialization in Game Design and Development</em>. It is my goal to design and develop video games on a professional level.
						<br /><br />
						For any comments, concerns, complaints, suggestions, or bits of miscellany feel free to leave a comment on any of the entries here, or email me at <a href="mailto: masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">masonm12@gmail.com</a>.
					</p>
					<h4 style="text-align: right;">August 25th, 2008</h4>
				</div>
			</div>
			<div id="sidebar">
				<div class="sidebox">
	<h2>Links: </h2>
	<p>
		<a href="index.php" title="Blog">Blog</a><br />
		<a href="projects.php" title="Projects">Projects</a><br />
		<a href="about.php" title="About">About</a><br />
		<a href="texts/resume.pdf" title="PDF | Resume">Resume</a><br />
		<a href="mailto: masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">Email</a>
	</p>
</div>				<div class="sidebox">
	<div class="buttons">
		<a href="http://profile.mygamercard.net/masonofsparta" title="Mathew's GamerTag | MasonOfSparta">
			<img src="http://card.mygamercard.net/masonofsparta.png" alt="Mathew's GamerTag | MasonOfSparta" />
		</a>
		<a href="http://www.spreadfirefox.com/node&amp;id=0&amp;t=321"><img alt="Foxkeh" title="Foxkeh" src="http://images.spreadfirefox.com/affiliates/Buttons/firefox3/foxkeh-fx3-180x60.png"/></a>
		<br />
		<a href="http://validator.w3.org/check?uri=referer"><img
			src="http://www.w3.org/Icons/valid-xhtml10"
			alt="Valid XHTML 1.0 Strict" /></a>
		<a href="http://jigsaw.w3.org/css-validator/">
			<img style="border:0;"
				src="http://jigsaw.w3.org/css-validator/images/vcss"
				alt="Valid CSS!" /></a>
	</div>
</div>			</div>
			<div id="footer">
				<h4>Design, development, and most everything else by <a href="mail:masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">Mathew Mason</a>, &copy; 2008.</h4>			</div>
		</div>
	</body>
</html>