<?xml version='1.0' encoding='UTF-8'?>
<!DOCTYPE html
	PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<title>Mathew Mason DOT com</title>
		
		<link rel="stylesheet" href="styles/general.css" type="text/css" />
		
		<script src="scripts/ufo.js" type="text/javascript"></script>
	</head>
	 	<body id="blog">
		<div id="page">
			<div id="header">
				<a href="index.php" title="Main Page"><img src="images/banner.jpg" alt="MathewMasonDOTcom" /></a>			</div>
			<div id="body">
				<div class="article">
<h1><a href="/index.php?id=16" title="View and post comments for Back To The Future">Back To The Future</a></h1>
<h4>Posted by <a href="mailto:masonm12@gmail.com" title="E-Mail Mathew at masonm12@gmail.com">Mathew</a> on December 4th, 2008</h4>
<br />
<p>
<script type="text/javascript">var FO1 = {movie:"http://www.youtube.com/v/P-8Ok-h2Ccc&amphl=en&ampfs=1", width:"425", height:"344", majorversion:"9", build:"0", xi:"true"};UFO.create(FO1, "youtuber_puppy");</script>Well, it's that time during my college career when I have to start thinking beyond the confines of the Engineering Building, and into what will hopefully become my future career. I keep telling myself that I'll wait until next semester to get really serious about speaking with employers, but I keep finding myself speaking with them now (with next week being finals week). Needless to say between finals, interviews, projects, and everything else it's been a bit stressful. Oh well, I'll just deal with it like any other stressful element... with youtube videos of puppies.<br />
<br />
</p><div id="youtuber_puppy" style="text-align: center;"></div><p><br /></p><h4 style="text-align: center;">Posted in <a href="/index.php?topic=Rant" title="All Rant posts">Rant</a></h4>

</div>

<div class="article">
<h1><a href="/index.php?id=15" title="View and post comments for GameJamming">GameJamming</a></h1>
<h4>Posted by <a href="mailto:masonm12@gmail.com" title="E-Mail Mathew at masonm12@gmail.com">Mathew</a> on November 21st, 2008</h4>
<br />
<p>
Thought I'd post that Spartasoft had another GameJam this past week, and it was as fun as they usually are (which is to say about 3 parts fun, 1 part stress, and 1 part sleep deprivation). Worked mostly with people I had worked with before (save for our audio guy) and overall it went very well. We took second place losing only to Charles Roman's game Ballz to the Wallz (link forthcoming) by 1 point.</p><div style="text-align: center;"><br />
<img src="images/GameJamNovember2008/DSC04108.JPG" alt="Chris Monosmith putting his game face on." title="Chris Monosmith putting his game face on." /><br />
<img src="images/GameJamNovember2008/DSC04109.JPG" alt="Day 1: Brainstorming" title="Day 1: Brainstorming" /><br />
<img src="images/GameJamNovember2008/DSC04112.JPG" alt="Day 2: Hard at work" title="Day 2: Hard at work" /><br />
<img src="images/GameJamNovember2008/DSC04113.JPG" alt="Day 3: Wishing we were sleeping" title="Day 3: Wishing we were sleeping" /></div><p><br /></p><h4 style="text-align: center;">Posted in <a href="/index.php?topic=Projects" title="All Projects posts">Projects</a></h4>

</div>

<div class="article">
<h1><a href="/index.php?id=14" title="View and post comments for Update">Update</a></h1>
<h4>Posted by <a href="mailto:masonm12@gmail.com" title="E-Mail Mathew at masonm12@gmail.com">Mathew</a> on October 23rd, 2008</h4>
<br />
<p>
So it's been a few weeks (like 6 or 7 or something) since I said I'd be making a game every few weeks this semester, and I have fallen dreadfully short of that goal. Between classes and GameJams I've almost made a game per month, but that's kind of cheating. Anyway, the semester has been busy enough to nearly crush my spirit, but I look forward to Christmas Break when hopefully I'll be able to actually get into some independent projects. In the meantime I should have some more class projects and GameJam projects to post between now and then.<br /></p><h4 style="text-align: center;">Posted in <a href="/index.php?topic=Projects" title="All Projects posts">Projects</a></h4>

</div>

<div class="article">
<h1><a href="/index.php?id=13" title="View and post comments for Works in Progress">Works in Progress</a></h1>
<h4>Posted by <a href="mailto:masonm12@gmail.com" title="E-Mail Mathew at masonm12@gmail.com">Mathew</a> on September 4th, 2008</h4>
<br />
<p>
<script type="text/javascript">var FO1 = {movie:"http://www.youtube.com/v/xgZKjJt-TkU&amp;hl=en&amp;fs=1", width:"425", height:"344", majorversion:"9", build:"0", xi:"true"};UFO.create(FO1, "youtuber_itouch");</script>Started "pre-production" on my first personally driven XNA project of the school year, and I'm hoping it'll last more than a few days this time around. Our basic project goal is to make a series of games, each taking around 2 or 3 weeks to complete (less if possible) and all building on the same basic code base. The reason behind all of this? We'd like to build up a nice, stable, tested base of code to take with us to next semester's game jam against U of M.<br />
<br />
The question I have now is whether or not I should post the project in progress as prototypes evolve. I've thought of adding some sort of updates system on the projects entries that would be appended to projects in a similar way to how comments are, but a little more integrated. I suppose I'll have to see how I feel about it about a week from now. Until then here's some funny vid I found featuring Mad TVs interpretation of Steve Jobs and the Mac-mania he generates. I'm personally a PC fanboy, but ordered an iPod Touch recently and couldn't be more excited to get it.<br />
<br />
</p><div id="youtuber_itouch" style="text-align: center;"></div><p><br /></p><h4 style="text-align: center;">Posted in <a href="/index.php?topic=Projects" title="All Projects posts">Projects</a></h4>

</div>

<div class="article">
<h1><a href="/index.php?id=12" title="View and post comments for Entries, posts, articles, and projects">Entries, posts, articles, and projects</a></h1>
<h4>Posted by <a href="mailto:masonm12@gmail.com" title="E-Mail Mathew at masonm12@gmail.com">Mathew</a> on August 26th, 2008</h4>
<br />
<p>
Finally finished adding all of my old projects, and fixing those that I had sloppily thrown together before. All in all this site is already making me more productive, which was part of the goal anyway.<br />
<br />
If anyone is reading this feel free to look at the projects page, and leave some feedback on some of the stuff there. I know it's not quite AAA stuff... yet, but I think I'm getting there slowly.<br /></p><h4 style="text-align: center;">Posted in <a href="/index.php?topic=Projects" title="All Projects posts">Projects</a></h4>

</div>

<div class="entries"><div class="nextentry"><a href="/index.php?offset=5" title="Older Posts">Older Posts (6-9) &gt;&gt;</a></div></div>			</div>
			<div id="sidebar">
				<div class="sidebox">
	<h2>Links: </h2>
	<p>
		<a href="index.php" title="Blog">Blog</a><br />
		<a href="projects.php" title="Projects">Projects</a><br />
		<a href="about.php" title="About">About</a><br />
		<a href="texts/resume.pdf" title="PDF | Resume">Resume</a><br />
		<a href="mailto: masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">Email</a>
	</p>
</div>				<div class="sidebox">
					<h2>Archive:</h2><p>
<a href="/index.php?month=12&amp;year=2008" title="Posts for December, 2008">December, 2008 (1)</a><br /><a href="/index.php?month=11&amp;year=2008" title="Posts for November, 2008">November, 2008 (1)</a><br /><a href="/index.php?month=10&amp;year=2008" title="Posts for October, 2008">October, 2008 (1)</a><br /><a href="/index.php?month=9&amp;year=2008" title="Posts for September, 2008">September, 2008 (1)</a><br /><a href="/index.php?month=8&amp;year=2008" title="Posts for August, 2008">August, 2008 (3)</a><br /><a href="/index.php?month=10&amp;year=2007" title="Posts for October, 2007">October, 2007 (1)</a><br /><a href="/index.php?month=1&amp;year=2007" title="Posts for January, 2007">January, 2007 (1)</a><br />
</p>
				</div>
				<div class="sidebox">
					<h2>Topics:</h2><p>
<a href="/index.php?topic=General" title="All General posts">General (1)</a><br /><a href="/index.php?topic=Humor" title="All Humor posts">Humor (1)</a><br /><a href="/index.php?topic=Projects" title="All Projects posts">Projects (4)</a><br /><a href="/index.php?topic=Rant" title="All Rant posts">Rant (3)</a><br />
</p>
				</div>
				<div class="sidebox">
	<div class="buttons">
		<a href="http://profile.mygamercard.net/masonofsparta" title="Mathew's GamerTag | MasonOfSparta">
			<img src="http://card.mygamercard.net/masonofsparta.png" alt="Mathew's GamerTag | MasonOfSparta" />
		</a>
		<a href="http://www.spreadfirefox.com/node&amp;id=0&amp;t=321"><img alt="Foxkeh" title="Foxkeh" src="http://images.spreadfirefox.com/affiliates/Buttons/firefox3/foxkeh-fx3-180x60.png"/></a>
		<br />
		<a href="http://validator.w3.org/check?uri=referer"><img
			src="http://www.w3.org/Icons/valid-xhtml10"
			alt="Valid XHTML 1.0 Strict" /></a>
		<a href="http://jigsaw.w3.org/css-validator/">
			<img style="border:0;"
				src="http://jigsaw.w3.org/css-validator/images/vcss"
				alt="Valid CSS!" /></a>
	</div>
</div>			</div>
			<div id="footer">
				<h4>Design, development, and most everything else by <a href="mail:masonm12@gmail.com" title="Email Mathew Mason at masonm12@gmail.com">Mathew Mason</a>, &copy; 2008.</h4>			</div>
		</div>
	</body>
</html>